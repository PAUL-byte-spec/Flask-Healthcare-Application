from flask import Flask, render_template, request
from pymongo import MongoClient

# Replace with your MongoDB connection details
client = MongoClient("mongodb://localhost:27017/")
db = client["your_database_name"]
collection = db["users"]

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def survey():
  if request.method == "POST":
    # Collect user data as before
    age = int(request.form["age"])
    gender = request.form["gender"]
    income = float(request.form["income"])
    expenses = {
      "utilities": float(request.form["utilities"] or 0),
      "entertainment": float(request.form["entertainment"] or 0),
      "school_fees": float(request.form["school_fees"] or 0),
      "shopping": float(request.form["shopping"] or 0),
      "healthcare": float(request.form["healthcare"] or 0),
    }
    
    # Create a document representing user data
    user_data = {
      "age": age,
      "gender": gender,
      "income": income,
      "expenses": expenses,
    }
    
    # Insert user data into MongoDB collection
    collection.insert_one(user_data)
    
    return "Thank you for your participation!"
  else:
    return render_template("survey.html")

if __name__ == "__main__":
  app.run(debug=True)


